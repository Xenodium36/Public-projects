/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Author:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 2
 #
 ####################################################################################################
*/

#ifndef IFJ_PROJ_2022_BUFFER_H
#define IFJ_PROJ_2022_BUFFER_H

#pragma once
// own includes below this line
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "error.h"

#define ALLOCATION_BLOCK_SIZE 10

typedef struct tokenString
{
    unsigned int strLen;
    unsigned int allocatedAmount;
    char *stringData;
} tokenString;

tokenString *createString();

/**
 * @brief initializes string (alocates memory ...)
 *
 * @param str - pointer to tokenString pointer
 * @return 1 was successful, 0 call print_err_msg(99)
 * @details memory allocation for tokenString
 */
int stringInit(tokenString *str);

/**
 * @brief appends char to predefined tokenString
 *
 * @param dest - tokenString pointer
 * @param add - char
 * @return 1 was successful, 0 call print_err_msg(99)
 * @details checking if we have enough space for char we want to add,
 * if not allocate memory, for both then define inside
 */
int charAppend(tokenString *dest, char add);

/**
 * @brief appends string to predefined tokenString
 *
 * @param dest - tokenString pointer
 * @param s - string
 * @return 1 was successful, 0 call print_err_msg(99)
 * @details checking if we have enough space for char we want to add,
 * if not allocate memory, for both then define inside
 */
int stringAppend(tokenString *dest, const char *s);

/**
 * @brief Prints out string to file
 *
 * @param source source string
 * @param f_output file pointer
 */
void stringPrint(tokenString *source, FILE *f_output);

/**
 * @brief removes all data from tokenString
 *
 * @param source - tokenString pointer
 * @return none - void
 * @details clears data in stringData and resets strLen to zero
 */
void stringClear(tokenString *source);

/**
 * @brief frees memory allocated by tokenString
 *
 * @param source - tokenString pointer
 * @return none - void
 * @details free memory allocated in data and pointer itself
 */
void stringFree(tokenString *source);

#endif // IFJ_PROJ_2021_22_BUFFER_H
