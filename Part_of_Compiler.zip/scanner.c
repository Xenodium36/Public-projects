/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Autor:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 1
 #
 ####################################################################################################
*/

#include "scanner.h"
#include "error.h"

//Defined global variables
FILE *f;
Token token;
char num[3];
char *name;

Token isKeyword(Token token, char *name)
{
    token.type = TOKEN_TYPE_KEYWORD;
    if (strcmp(name, "else") == 0)
        token.attribute.keyword = KEYWORD_ELSE;
    else if (strcmp(name, "function") == 0)
        token.attribute.keyword = KEYWORD_FUNCTION;
    else if (strcmp(name, "if") == 0)
        token.attribute.keyword = KEYWORD_IF;
    else if (strcmp(name, "return") == 0)
        token.attribute.keyword = KEYWORD_RETURN;
    else if (strcmp(name, "while") == 0)
        token.attribute.keyword = KEYWORD_WHILE;
    else if (strcmp(name, "int") == 0)
        token.attribute.keyword = KEYWORD_INTEGER;
    else if (strcmp(name, "float") == 0)
        token.attribute.keyword = KEYWORD_FLOAT;
    else if (strcmp(name, "string") == 0)
        token.attribute.keyword = KEYWORD_STRING;
    else if (strcmp(name, "boolean") == 0)
        token.attribute.keyword = KEYWORD_BOOLEAN;
    else if (strcmp(name, "?int") == 0)
        token.attribute.keyword = KEYWORD_Q_INTEGER;
    else if (strcmp(name, "?float") == 0)
        token.attribute.keyword = KEYWORD_Q_FLOAT;
    else if (strcmp(name, "?string") == 0)
        token.attribute.keyword = KEYWORD_Q_STRING;
    else if (strcmp(name, "for") == 0)
        token.attribute.keyword = KEYWORD_FOR;
    else if (strcmp(name, "break") == 0)
        token.attribute.keyword = KEYWORD_BREAK;
    else if (strcmp(name, "continue") == 0)
        token.attribute.keyword = KEYWORD_CONTINUE;
    else if (strcmp(name, "elseif") == 0)
        token.attribute.keyword = KEYWORD_ELSEIF;
    else if (strcmp(name, "null") == 0)
        token.attribute.keyword = KEYWORD_NULL;
    else if (strcmp(name, "true") == 0)
    {
        token.attribute.boolean = true;
        token.type = TOKEN_TYPE_BOOLEAN;
        free(name);
        return token;
    }
    else if (strcmp(name, "false") == 0)
    {
        token.attribute.boolean = false;
        token.type = TOKEN_TYPE_BOOLEAN;
        free(name);
        return token;
    }
    else
        token.type = TOKEN_TYPE_ID;

    if (token.type != TOKEN_TYPE_ID)
    {
        free(name);
        return token;
    }
    else
    {
        token.attribute.string = name;
        return token;
    }
}

void scanner_init(FILE *file)
{
    if (file == NULL)
        print_err_msg(99);
    else
        f = file;
}

int myPow(int base, int exp)
{
    int result = 1;
    for (exp; exp > 0; exp--)
    {
        result = result * base;
    }
    return result;
}

int OctalToDecimal(int n)
{
    int p = 0, decimal = 0, r;

    while (n > 0)
    {
        r = n % 10;
        n = n / 10;
        decimal = decimal + r * myPow(8, p);
        ++p;
    }
    return decimal;
}

char *allocName()
{
    char *tmp = (char *)malloc(MAX_LENGTH);
    if (tmp == NULL)
        print_err_msg(99);
    memset(tmp, 0, 1024);
    return tmp;
}

Token getToken()
{
    //set default values of token
    char c;
    State state = STATE_START;
    token.attribute.integer = 0;
    token.attribute.keyword = EMPTY;
    token.attribute.number = 0.0;
    token.attribute.string = NULL;
    token.attribute.boolean = false;
    // State automaton described in the documentation
    while (true)
    {
        c = (char)getc(f);
        switch (state)
        {
        case STATE_START:
            if (c == EOF)
            {
                token.type = TOKEN_TYPE_EOF;
                return token;
            }
            if (isspace(c) || c == '\n')
                continue;
            if (c == '/')
            {
                state = STATE_DIV;
                continue;
            }
            if (c == '*')
            {
                token.type = TOKEN_TYPE_MUL;
                return token;
            }
            if (c == '-')
            {
                token.type = TOKEN_TYPE_MINUS;
                return token;
            }
            if (c == '+')
            {
                token.type = TOKEN_TYPE_PLUS;
                return token;
            }
            if (c == '=')
            {
                state = STATE_EQL;
                continue;
            }
            if (c == '>')
            {
                state = STATE_GTE;
                continue;
            }
            if (c == '<')
            {
                state = STATE_LTE;
                continue;
            }
            if (c == ',')
            {
                token.type = TOKEN_TYPE_COMMA;
                return token;
            }
            if (c == '(')
            {
                token.type = TOKEN_TYPE_LEFT_BRACKET;
                return token;
            }
            if (c == ')')
            {
                token.type = TOKEN_TYPE_RIGHT_BRACKET;
                return token;
            }
            if (c == ';')
            {
                token.type = TOKEN_TYPE_SCOL;
                return token;
            }
            if (c == '{')
            {
                token.type = TOKEN_TYPE_LEFT_CURLY_BRACKET;
                return token;
            }
            if (c == '}')
            {
                token.type = TOKEN_TYPE_RIGHT_CURLY_BRACKET;
                return token;
            }
            if (c == '.')
            {
                token.type = TOKEN_TYPE_DOT;
                return token;
            }
            if (c == ':')
            {
                token.type = TOKEN_TYPE_DOUBLEDOT;
                return token;
            }
            if (c == '!')
            {
                state = STATE_NEQL_1;
                continue;
            }
            if (c == '$')
            {
                name = allocName();
                strncat(name, &c, 1);
                state = STATE_VAR;
                continue;
            }
            if (c == '?')
            {
                name = allocName();
                strncat(name, &c, 1);
                state = STATE_QMARK;
                continue;
            }
            if (isalpha(c) || c == '_')
            {
                name = allocName();
                strncat(name, &c, 1);
                state = STATE_ID;
                continue;
            }
            if (isdigit(c))
            {
                name = allocName();
                strncat(name, &c, 1);
                state = STATE_NUM;
                continue;
            }
            if (c == '"')
            {
                name = allocName();
                // strncat(name, &c, 1);
                state = STATE_QUOTATION_MARK;
                continue;
            }
            print_err_msg(1);
        case STATE_QUOTATION_MARK:
            if (c >= 32 && (c != '\\' && c != '"' && c != '$'))
            {
                strncat(name, &c, 1);
                continue;
            }
            else if (c == '"')
            {
                // strncat(name, &c, 1);
                token.type = TOKEN_TYPE_STRING;
                token.attribute.string = name;
                return token;
            }
            else if (c == '\\')
            {
                state = STATE_SLASH;
                continue;
            }
            else
            {
                free(name);
                print_err_msg(1);
            }

        case STATE_SLASH:
            if (c == '\\')
            {
                strncat(name, &c, 1);
                state = STATE_QUOTATION_MARK;
                continue;
            }
            else if (c == '"')
            {
                // strncat(name, &c, 1);
                state = STATE_QUOTATION_MARK;
                continue;
            }
            else if (c == 'n')
            {
                char tmp = '\n';
                strncat(name, &tmp, 1);
                state = STATE_QUOTATION_MARK;
                continue;
            }
            else if (c == 't')
            {
                char tmp = '\t';
                strncat(name, &tmp, 1);
                state = STATE_QUOTATION_MARK;
                continue;
            }
            else if (c == '$')
            {
                strncat(name, &c, 1);
                state = STATE_QUOTATION_MARK;
                continue;
            }
            else if (c == 'x')
            {
                state = STATE_HEX;
                continue;
            }
            else if (c >= 48 && c <= 51)
            {
                memset(num, 0, 3);
                strncat(num, &c, 1);
                state = STATE_CHAR;
                continue;
            }
            else
            {
                free(name);
                print_err_msg(1);
            }
        case STATE_HEX:
            memset(num, 0, 3);
            strncat(num, &c, 1);
            state = STATE_HEX_1;
            continue;
        case STATE_HEX_1:
            strncat(num, &c, 1);
            int tmp = (int)strtol(num, NULL, 16);
            if (tmp < 1 || tmp > 255)
            {
                free(name);
                print_err_msg(1);
            }
            strncat(name, &tmp, 1);
            state = STATE_QUOTATION_MARK;
            continue;
        case STATE_CHAR:
            if (c >= 48 && c <= 57)
            {
                strncat(num, &c, 1);
                state = STATE_CHAR_1;
                continue;
            }
            else
            {
                free(name);
                print_err_msg(1);
            }

        case STATE_CHAR_1:
            if (c >= 48 && c <= 57)
            {
                strncat(num, &c, 1);
                if (atoi(num) < 1 || atoi(num) > 377)
                {
                    free(name);
                    print_err_msg(1);
                }
                char tmp = OctalToDecimal(atoi(num));
                strncat(name, &tmp, 1);
                state = STATE_QUOTATION_MARK;
                continue;
            }
            else
            {
                free(name);
                print_err_msg(1);
            }

        case STATE_NUM:
            if (isdigit(c))
            {
                strncat(name, &c, 1);
                continue;
            }
            else if (c == 'e' || c == 'E')
            {
                strncat(name, &c, 1);
                state = STATE_EXP;
                continue;
            }
            else if (c == '.')
            {
                strncat(name, &c, 1);
                state = STATE_NEED_NUM_DBL;
                continue;
            }
            else
            {
                token.type = TOKEN_TYPE_INT;
                strncat(name, &c, 1);
                token.attribute.integer = atoi(name);
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                free(name);
                return token;
            }
        case STATE_NEED_NUM_DBL:
            if (isdigit(c))
            {
                strncat(name, &c, 1);
                state = STATE_DOUBLE;
                continue;
            }
            free(name);
            print_err_msg(1);
        case STATE_EXP:
            if (c == '+' || c == '-')
            {
                strncat(name, &c, 1);
                state = STATE_NEED_NUM_EXP;
                continue;
            }
            else if (isdigit(c))
            {
                strncat(name, &c, 1);
                state = STATE_EXP_F;
                continue;
            }
            free(name);
            print_err_msg(1);
        case STATE_NEED_NUM_EXP:
            if (isdigit(c))
            {
                strncat(name, &c, 1);
                state = STATE_EXP_F;
                continue;
            }
            free(name);
            print_err_msg(1);
        case STATE_EXP_F:
            if (isdigit(c))
            {
                strncat(name, &c, 1);
                continue;
            }
            else
            {
                token.type = TOKEN_TYPE_FLOAT;
                token.attribute.number = atof(name);
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                free(name);
                return token;
            }

        case STATE_DOUBLE:
            if (isdigit(c))
            {
                strncat(name, &c, 1);
                continue;
            }
            else if (c == 'e' || c == 'E')
            {
                strncat(name, &c, 1);
                state = STATE_EXP;
                continue;
            }
            else
            {
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                token.type = TOKEN_TYPE_FLOAT;
                token.attribute.number = atof(name);
                free(name);
                return token;
            }

        case STATE_ID:
            if (isalnum(c) || c == '_')
            {
                strncat(name, &c, 1);
                continue;
            }
            else
            {
                token = isKeyword(token, name);
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                return token;
            }
        case STATE_QMARK:
            if (islower(c))
            {
                strncat(name, &c, 1);
                continue;
            }
            else
            {
                token = isKeyword(token, name);
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);

                return token;
            }
        case STATE_VAR:
            if (isalnum(c) || c == '_')
            {
                strncat(name, &c, 1);
                continue;
            }
            else
            {
                token.type = TOKEN_TYPE_VAR;
                token.attribute.string = name;
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                return token;
            }
        case STATE_NEQL_1:
            if (c == '=')
            {
                state = STATE_NEQL_E;
                continue;
            }
            print_err_msg(1);
        case STATE_NEQL_E:
            if (c == '=')
            {
                token.type = TOKEN_TYPE_NEQ;
                return token;
            }
            print_err_msg(1);
        case STATE_LTE:
            if (c == '=')
            {
                token.type = TOKEN_TYPE_LESS_EQ;
                return token;
            }
            else
            {
                token.type = TOKEN_TYPE_LESS;
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                return token;
            }
        case STATE_GTE:
            if (c == '=')
            {
                token.type = TOKEN_TYPE_MORE_EQ;
                return token;
            }
            else
            {
                token.type = TOKEN_TYPE_MORE;
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                return token;
            }
        case STATE_EQL:
            if (c == '=')
            {
                state = STATE_EQL_E;
                continue;
            }
            else
            {
                token.type = TOKEN_TYPE_ASSIGN;
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                return token;
            }
        case STATE_EQL_E:
            if (c == '=')
            {
                token.type = TOKEN_TYPE_EQ;
                return token;
            }
            print_err_msg(1);
        case STATE_DIV:
            if (c == '/')
            {
                fscanf(f, "%*[^\n]\n");
                state = STATE_START;
                continue;
            }
            else if (c == '*')
            {
                state = STATE_B_COMM;
                continue;
            }
            else
            {
                token.type = TOKEN_TYPE_DIV;
                if (c != EOF)
                    fseek(f, -1, SEEK_CUR);
                return token;
            }
        case STATE_B_COMM:
            if (c == '*')
            {
                state = STATE_B_COMM_TE;
                continue;
            }
            else if (c == EOF)
                print_err_msg(1);
            else
                continue;

        case STATE_B_COMM_TE:
            if (c == '/')
            {
                state = STATE_START;
                continue;
            }
            else
            {
                state = STATE_B_COMM;
                continue;
            }
        default:
            print_err_msg(1);
        }
    }
}