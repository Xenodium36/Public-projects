/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Authors:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 2
 #
 ####################################################################################################
*/

#include "ast.h"

/// @struct Create data structure linked list
struct linked_list
{
   struct gen_node *head;
   struct gen_node *last;
};

/// @struct Nodes of linked lists
struct gen_node
{
   struct ast_node *data;

   struct gen_node *next;
   struct gen_node *prev;
};

/**
 * @brief Check, if linked list is empty
 * 
 * @return true 
 * @return false 
 */
bool isEmpty(struct linked_list *);

/**
 * @brief Get length of linked list
 * 
 * @param 1 Pointer to linked list
 * 
 * @return int 
 */
int length(struct linked_list *);

/**
 * @brief Insert node to linked list to last position
 * 
 * @param 1 Pointer to linked list struct
 * @param 2 node to insert
 */
void insertLast(struct linked_list *, struct ast_node *);

/**
 * @brief Initialie memory for linked list
 * 
 * @return struct linked_list* pointer to linked list
 */
struct linked_list *initLinkedList();

/**
 * @brief Delete first node of linked list
 * 
 * @return struct ast_node* Pointer to first node
 */
struct ast_node *deleteFirst(struct linked_list *);

/**
 * @brief Delete last node of linked list
 * 
 * @return struct ast_node* pointer to last node
 */
struct ast_node *deleteLast(struct linked_list *);