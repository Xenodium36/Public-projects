/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Authors:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 3
 #
 ####################################################################################################
*/

#include "code_gen.h"

// buffer for output
tokenString *buffer;

// Global variables
struct ast_node *ast_curr;
struct ast_node *ast_func_call;
struct node_data_as_function_declare *function_declare;
struct linked_list *stack;      // stack for whole AST
struct linked_list *expr_stack; // Stack only for expressions

int while_started;
int if_started;
int else_started;
int elseif_started;
int while_ended;
int if_ended;
int else_ended;
int elseif_ended;

void fnc_call()
{
    // function call data
    struct node_data_as_function_call *function_call = (struct node_data_as_function_call *)ast_curr->data->payload;
    gen_startParamsPass();
    ast_curr = deleteFirst(stack);
    // check all childrens of function call -> parameters
    if (ast_curr->ast_nodes == NULL)
    {
        gen_functionCall(function_call->name);
        return;
    }
    for (int i = 0; i < ast_curr->ast_nodes->length; i++)
    {
        char num[2] = "";
        sprintf(num, "%d", i);
        char dest[] = "$";
        deleteFirst(stack);
        struct ast_node_data *arg_node = (struct ast_node_data *)ast_curr->ast_nodes->array[i].data;
        switch (arg_node->type)
        {
            // if parameter is value
        case VALUE:;
            struct node_data_as_value *value = (struct node_data_as_value *)arg_node->payload;
            gen_paramPass(dest, "TF");
            if (value->type == VAR_TYPE_INT)
                gen_int(*(int *)value->payload);
            if (value->type == VAR_TYPE_STRING)
                gen_string(value->payload);
            if (value->type == VAR_TYPE_FLOAT)
                gen_float(*(float *)value->payload);
            gen_newline();
            break;
        // parameter == variable
        case VARIABLE:;
            struct node_data_as_variable *variable = (struct node_data_as_variable *)arg_node->payload;
            strcat(dest, num);
            gen_paramPass(dest, "TF");
            gen_varName(variable->name, "LF");
            gen_newline();
            break;
        case FUNCTION_CALL:;
            // fnc_call();
            break;
        case EXPRESSION:; // nf
            break;
        default:
            break;
        }
    }
    gen_functionCall(function_call->name);
}

void fnc_call_exp(struct ast_node *fnc_call)
{
    // function call data
    struct node_data_as_function_call *function_call = (struct node_data_as_function_call *)fnc_call->data->payload;
    gen_startParamsPass();
    fnc_call = deleteLast(expr_stack);
    // check all childrens of function call -> parameters
    if (fnc_call->ast_nodes == NULL)
    {
        gen_functionCall(function_call->name);
        return;
    }
    for (int i = 0; i < fnc_call->ast_nodes->length; i++)
    {
        char num[2] = "";
        sprintf(num, "%d", i);
        char dest[] = "$";
        deleteLast(expr_stack);
        struct ast_node_data *arg_node = (struct ast_node_data *)fnc_call->ast_nodes->array[i].data;
        switch (arg_node->type)
        {
            // if parameter is value
        case VALUE:;
            struct node_data_as_value *value = (struct node_data_as_value *)arg_node->payload;
            gen_paramPass(dest, "TF");
            if (value->type == VAR_TYPE_INT)
                gen_int(*(int *)value->payload);
            if (value->type == VAR_TYPE_STRING)
                gen_string(value->payload);
            if (value->type == VAR_TYPE_FLOAT)
                gen_float(*(float *)value->payload);
            gen_newline();
            break;
        case VARIABLE:;
            struct node_data_as_variable *variable = (struct node_data_as_variable *)arg_node->payload;
            strcat(dest, num);
            gen_paramPass(dest, "TF");
            gen_varName(variable->name, "LF");
            gen_newline();
            break;
        case FUNCTION_CALL:;
            break;
        case EXPRESSION:; // nf
            break;
        default:
            break;
        }
    }
    gen_functionCall(function_call->name);
}

void expr_value(struct ast_node *tmp1)
{
    if (tmp1->data->type == VALUE)
    {
        struct node_data_as_value *tmp1val = tmp1->data->payload;
        if ((tmp1val->type == VAR_TYPE_INT) || (tmp1val->type == VAR_TYPE_STRING) || (tmp1val->type == VAR_TYPE_BOOL))
        {
            gen_stackPush();
            gen_int(*(int *)tmp1val->payload);
            gen_newline();
        }
        if (tmp1val->type == VAR_TYPE_FLOAT)
        {
            gen_stackPush();
            gen_float(*(float *)tmp1val->payload);
            gen_newline();
        }
    }
    else if (tmp1->data->type == VARIABLE)
    {
        struct node_data_as_variable *tmp1var = tmp1->data->payload;
        if (tmp1var->define == true)
        {
            gen_varDeclaration(tmp1var->name, "LF");
        }
        gen_stackPush();
        gen_varName(tmp1var->name, "LF");
        gen_newline();
    }
}

void math_expr(struct ast_node *tmp1, struct ast_node *tmp2,
               struct node_data_as_expression *exp)
{
    if (tmp1 != NULL)
        expr_value(tmp1);
    if (tmp2 != NULL)
        expr_value(tmp2);

    // generate mathematical operation
    switch (exp->type)
    {
    case ADD:;
        gen_stackOp("+");
        break;

    case SUBS:;
        gen_stackOp("-");
        break;

    case MUL:;
        gen_stackOp("*");
        break;

    case DIV:;
        gen_stackOp("/");
        break;

    case LESS:;
        gen_stackOp("<");
        break;

    case LESS_EQ:;
        gen_stackOp("l");
        break;

    case GREATER:;
        gen_stackOp(">");
        break;

    case GREATER_EQ:;
        gen_stackOp("g");
        break;

    case EQUAL:;
        gen_stackOp("e");
        break;

    case NOT_EQUAL:;
        gen_stackOp("q");
        break;
    }
}

void assign_expr(struct ast_node *tmp1, struct ast_node *tmp2,
                 struct node_data_as_expression *exp)
{
    struct node_data_as_variable *tmp2var = tmp2->data->payload;
    if (tmp2var->define == true)
    {
        gen_varDeclaration(tmp2var->name, "LF");
    }

    if (tmp1->data->type == VARIABLE)
    {
        struct node_data_as_variable *tmp1var = tmp1->data->payload;
        if (tmp1var->define == true)
        {
            gen_varDeclaration(tmp1var->name, "LF");
        }

        switch (exp->type)
        {
        case ASSIGN:;
            gen_opt_var_var("=", tmp2var->name, tmp1var->name);
            break;
        case CONCAT:;
            gen_opt_var_var("U", tmp2var->name, tmp1var->name);
            break;
        }
    }
    else if (tmp1->data->type == VALUE)
    {
        struct node_data_as_value *tmp1val = (struct node_data_as_value *)tmp1->data->payload;

        switch (exp->type)
        {
        case ASSIGN:;

            stringAppend(buffer, "MOVE LF@");
            stringAppend(buffer, tmp2var->name);
            stringAppend(buffer, " ");
            if (tmp1val->type == VAR_TYPE_INT)
            {
                gen_int(payload_to_int(tmp1val));
            }
            else if (tmp1val->type == VAR_TYPE_FLOAT)
            {
                gen_float(payload_to_float(tmp1val));
            }
            else if (tmp1val->type == VAR_TYPE_STRING)
            {
                gen_string((char *)tmp1val->payload);
            }
            gen_newline();
            break;
        case CONCAT:;

            break;
        }
    }
    else if (tmp1->data->type == FUNCTION_CALL)
    {
        gen_varAssign(tmp2var->name, "LF");
        stringAppend(buffer, "TF@$return_val1\n");
    }
}

void assign_expr_stack(struct ast_node *tmp1, struct node_data_as_expression *exp)
{
    if (tmp1->data->type == VARIABLE)
    {
        struct node_data_as_variable *tmp1var = tmp1->data->payload;
        if (tmp1var->define == true)
            gen_varDeclaration(tmp1var->name, "LF");
        gen_stackPop();
        gen_varName(tmp1var->name, "LF");
        gen_newline();
    }
}

void expr()
{
    while (expr_stack->head != NULL)
    {
        struct ast_node *tmp1 = deleteLast(expr_stack); // First atribute
        if (tmp1->data->type == FUNCTION_CALL)
        {
            fnc_call_exp(tmp1);
            deleteLast(expr_stack);
        }
        if (tmp1->data->type == EXPRESSION)
        {
            struct node_data_as_expression *exp = tmp1->data->payload;
            math_expr(NULL, NULL, exp);
            continue;
        }

        struct ast_node *tmp2 = deleteLast(expr_stack); // Second artibute
        if (tmp2->data->type == EXPRESSION)
        {
            struct node_data_as_expression *exp = tmp2->data->payload;
            if (tmp1->data->type == VALUE || tmp1->data->type == VARIABLE)
            {
                struct node_data_as_expression *exp = tmp2->data->payload;
                if (exp->type == ASSIGN)
                    assign_expr_stack(tmp1, exp);
                else
                    math_expr(tmp1, NULL, exp);
                continue;
            }
            if(tmp1->data->type == FUNCTION_CALL)
            {
                gen_stackPush();
                gen_varName("$return_val1", "TF");
                gen_newline();
            }
            if (exp->type == ASSIGN)
            {
                assign_expr_stack(tmp1, exp);
            }
            else
            {
                math_expr(NULL, tmp2, exp);
            }
            continue;
        }
        if (tmp2->data->type == FUNCTION_CALL)
        {
            fnc_call_exp(tmp2);
            gen_stackPush();
            gen_varName("$return_val1", "TF");
            gen_newline();
            deleteLast(expr_stack);
        }
        struct ast_node *tmpexp = deleteLast(expr_stack); // expression type
        if((tmp2->data->type == VALUE || tmp2->data->type == VARIABLE) &&
            (tmpexp->data->type == VALUE || tmpexp->data->type == VARIABLE))
        {
            gen_stackPush();
            gen_varName("$return_val1", "TF");
            gen_newline();
            struct ast_node *next_exp = deleteLast(expr_stack);
            struct node_data_as_expression *exp_tmp = next_exp->data->payload;
            math_expr(tmp2, tmpexp, exp_tmp);
            continue;
        }
        struct node_data_as_expression *exp = tmpexp->data->payload;

        if ((exp->type == ASSIGN) || (exp->type == CONCAT))
        {
            assign_expr(tmp1, tmp2, exp);
        }
        else
        {
            if (tmp2->data->type == FUNCTION_CALL)
            {
                if (exp->type == ASSIGN)
                {
                    assign_expr_stack(tmp1, exp);
                }
                else
                {
                    math_expr(tmp1, NULL, exp);
                }
            }
            else if (tmp1->data->type == FUNCTION_CALL)
            {
                if (exp->type == ASSIGN)
                {
                    assign_expr_stack(tmp2, exp);
                }
                else
                {
                    gen_stackPush();
                    gen_varName("$return_val1", "TF");
                    gen_newline();
                    math_expr(NULL, tmp2, exp);
                }
            }
            else
            {
                math_expr(tmp1, tmp2, exp);
            }
        }
    }
}

void crossroad()
{
    // Run, while there is OP on stack, and decide, what to do, using data->type
    while (true)
    {
        ast_curr = deleteFirst(stack);
        if (ast_curr == NULL)
            return;
        if (ast_curr->data->type == FUNCTION_DECLARE)
        {
            function_declare = (struct node_data_as_function_declare *)ast_curr->data->payload;
            gen_functionStart(function_declare->name);
            ast_curr = deleteFirst(stack);
            if (ast_curr->ast_nodes != NULL)
            {
                for (int i = 0; i < ast_curr->ast_nodes->length; i++)
                {
                    struct node_data_as_variable *variable = (struct node_data_as_variable *)ast_curr->ast_nodes->array[i].data->payload;
                    deleteFirst(stack);
                    gen_paramPass(variable->name, "LF");
                    char num[2] = "";
                    sprintf(num, "%d", i);
                    char dest[] = "$";
                    strcat(dest, num);
                    gen_varName(dest, "LF");
                    gen_newline();
                }
            }
        }
        if (ast_curr->data->type == FUNCTION_DECLARE_END)
        {
            gen_functionEnd(function_declare->name);
        }
        if (ast_curr->data->type == EXIT)
        {
            gen_exit(0);
        }
        if (ast_curr->data->type == RETURN)
        {
            if (ast_curr->ast_nodes == NULL)
            {
                continue;
            }
            else
            {
                ast_curr = deleteFirst(stack);
                gen_functionReturn(1);
            }
            switch (ast_curr->data->type)
            {
            case VALUE:;
                struct node_data_as_value *value = (struct node_data_as_value *)ast_curr->data->payload;
                if (value->type == VAR_TYPE_INT)
                {
                    int *i = (int *)value->payload;
                    gen_int(*i);
                    gen_newline();
                }
                if (value->type == VAR_TYPE_STRING)
                {
                    gen_string(value->payload);
                    gen_newline();
                }
                if (value->type == VAR_TYPE_FLOAT)
                {
                    float *f = (float *)value->payload;
                    gen_float(*f);
                    gen_newline();
                }
                break;
            case VARIABLE:;
                struct node_data_as_variable *variable = (struct node_data_as_variable *)ast_curr->data->payload;
                gen_varName(variable->name, "LF");
                gen_newline();
                if (variable->define)
                {
                }
                break;
            case FUNCTION_CALL:; // nf
                struct node_data_as_function_call *function_call = (struct node_data_as_function_call *)ast_curr->data->payload;
                printf("FUNCTION_CALL: %s\n", function_call->name);
                break;
            case EXPRESSION:; // nf
                break;
            }
        }
        if (ast_curr->data->type == EXPRESSION)
        { // nf
            fill_ExprStack(ast_curr);
            expr();
            //clearExprStack();
        }
        if (ast_curr->data->type == FUNCTION_CALL)
        {
            fnc_call();
        }
    }
}

void clearExprStack()
{
    while (deleteLast(expr_stack))
        ;
}

void insertFncCall(struct ast_node *ast_node)
{
    if (ast_node == NULL)
        return;
    if (ast_node->ast_nodes != NULL)
    {
        for (size_t i = 0; i < ast_node->ast_nodes->length; i++)
        {
            struct ast_node *n = &(ast_node->ast_nodes->array[i]);
            insertFncCall(n);
        }
    }
    insertLast(expr_stack, ast_node);
    ast_curr = deleteFirst(stack);
}

void fill_ExprStack(struct ast_node *ast_node)
{
    if (ast_node != NULL)
    {
        if (ast_node->data->type != FUNCTION_CALL && ast_node->data->type != FUNCTION_CALL_END)
        {
            if (ast_node->data->type != EXPRESSION)
            {
                ast_curr = deleteFirst(stack);
            }
            insertLast(expr_stack, ast_node);
        }
    }
    else
        return;
    if (ast_node->ast_nodes != NULL)
    {
        for (size_t i = 0; i < ast_node->ast_nodes->length; i++)
        {
            struct ast_node *n = &(ast_node->ast_nodes->array[i]);
            if (n->data->type == FUNCTION_CALL)
            {
                insertLast(expr_stack, &(ast_node->ast_nodes->array[i + 1]));
                insertFncCall(n);
                continue;
            }
            if (n->data->type == EXPRESSION)
            {
                ast_curr = deleteFirst(stack);
            }
            fill_ExprStack(n);
        }
    }
}

void fill_Stack(struct ast_node *ast_node)
{
    if (ast_node != NULL)
    {
        insertLast(stack, ast_node);
    }
    else
        return;
    if (ast_node->ast_nodes != NULL)
    {
        for (size_t i = 0; i < ast_node->ast_nodes->length; i++)
        {
            struct ast_node *n = &(ast_node->ast_nodes->array[i]);
            fill_Stack(n);
        }
    }
}

void gen_assembly(struct ast_node *root)
{
    buffer = initCodeGen();
    stack = initLinkedList();
    expr_stack = initLinkedList();
    fill_Stack(root);
    crossroad();
    finiCodeGen(buffer);
}