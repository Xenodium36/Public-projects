/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Author:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 2
 #
 ####################################################################################################
*/

#include "buffer.h"

tokenString *createString()
{
    tokenString *tmp = malloc(sizeof(tokenString));
    if (!tmp)
        print_err_msg(99);
    stringInit(tmp);
    return tmp;
}

int stringInit(tokenString *tmp)
{

    tmp->strLen = 0;
    tmp->allocatedAmount = ALLOCATION_BLOCK_SIZE;

    char *tmpArr = calloc(ALLOCATION_BLOCK_SIZE, sizeof(char));

    // since first allocation of memory was successful and second was not
    // we have to free the first allocated memory
    if (!tmpArr)
    {
        free(tmp);
        return 0;
    }

    tmp->stringData = tmpArr;

    return 1;
}

int charAppend(tokenString *dest, char add)
{

    // + 2 > strLen = amount of non-zero characters, 1 for new char, 1 for end zero
    if (dest->strLen + 2 < dest->allocatedAmount)
    {

        dest->stringData = (char *)realloc(dest->stringData, dest->strLen + ALLOCATION_BLOCK_SIZE);
        dest->allocatedAmount = dest->allocatedAmount + ALLOCATION_BLOCK_SIZE;

        if (dest->stringData == NULL)
        {
            return 0;
        }
    }

    dest->stringData[dest->strLen] = add;
    dest->strLen++;
    dest->stringData[dest->strLen] = '\0';

    return 1;
}

int stringAppend(tokenString *dest, const char *s)
{
    //If not enough memmory, alloc more
    if (dest->strLen + strlen(s) + 1 >= dest->allocatedAmount)
    {
        dest->stringData = (char *)realloc(dest->stringData, dest->strLen + strlen(s) + 1);
        if (dest->stringData == NULL)
        {
            print_err_msg(99);
            return -1;
        }

        dest->allocatedAmount = dest->strLen + strlen(s) + 1;
    }

    strcat(dest->stringData, s);
    dest->strLen += strlen(s);
    dest->stringData[dest->strLen] = '\0';
    return 0;
}

void stringPrint(tokenString *source, FILE *dest)
{
    fputs(source->stringData, dest);
    stringFree(source);
}

void stringClear(tokenString *source)
{
    source->stringData[0] = '\0';
    source->strLen = 0;
}

void stringFree(tokenString *source)
{
    free(source->stringData);
}
