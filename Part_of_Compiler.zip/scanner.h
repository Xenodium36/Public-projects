/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Autor:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 1
 #
 ####################################################################################################
*/

#ifndef IFJ_PROJ_2022_SCANNER_H
#define IFJ_PROJ_2022_SCANNER_H

#pragma once
#include <stdio.h>
#include <stdlib.h>

// own includes below this line
#include "string.h"
#include <stdbool.h>
#include <ctype.h>
#include "error.h"

#define MAX_LENGTH 1024


/**
 * @enum Defined keywords.
 */
typedef enum
{
    EMPTY,

    KEYWORD_FUNCTION,
    KEYWORD_VOID,

    KEYWORD_Q_INTEGER,
    KEYWORD_INTEGER,
    KEYWORD_Q_FLOAT,
    KEYWORD_FLOAT,
    KEYWORD_Q_STRING,
    KEYWORD_STRING,
    KEYWORD_BOOLEAN,
    KEYWORD_NULL,

    KEYWORD_IF,
    KEYWORD_ELSEIF,
    KEYWORD_ELSE,

    KEYWORD_WHILE,

    KEYWORD_FOR,
    KEYWORD_BREAK,
    KEYWORD_CONTINUE,

    KEYWORD_RETURN

} Keyword;

/**
 * @enum Type of token.
 */
typedef enum
{

    TOKEN_TYPE_ID, // ID
    TOKEN_TYPE_VAR,
    TOKEN_TYPE_KEYWORD, // Keyword

    TOKEN_TYPE_INT,     // Integer
    TOKEN_TYPE_FLOAT,   // FLOAT
    TOKEN_TYPE_STRING,  // String
    TOKEN_TYPE_BOOLEAN, // Boolean

    TOKEN_TYPE_ASSIGN, // =

    TOKEN_TYPE_PLUS,  // +
    TOKEN_TYPE_MINUS, // -
    TOKEN_TYPE_MUL,   // *
    TOKEN_TYPE_DIV,   // /

    TOKEN_TYPE_NEQ,     // !==
    TOKEN_TYPE_EQ,      // ===
    TOKEN_TYPE_MORE,    // >
    TOKEN_TYPE_LESS,    // <
    TOKEN_TYPE_MORE_EQ, // >=
    TOKEN_TYPE_LESS_EQ, // <=

    TOKEN_TYPE_LEFT_BRACKET,        // (
    TOKEN_TYPE_RIGHT_BRACKET,       // )
    TOKEN_TYPE_RIGHT_CURLY_BRACKET, // {
    TOKEN_TYPE_LEFT_CURLY_BRACKET,  // }
    TOKEN_TYPE_COMMA,               // ,
    TOKEN_TYPE_DOUBLEDOT,           // :
    TOKEN_TYPE_SCOL,                // ;
    TOKEN_TYPE_DOT,                 // .

    TOKEN_TYPE_DOLLAR,     // $
    TOKEN_TYPE_MORE_STACK, // > (stack)
    TOKEN_TYPE_LESS_STACK, // < (stack)
    TOKEN_TYPE_EQ_STACK,   // = (stack)

    TOKEN_TYPE_EOF, // End of file
    TOKEN_TYPE_ERROR,
    TOKEN_TYPE_NONTERM
} tokenType;


/**
 * @enum States of the automaton
 */
typedef enum
{
    STATE_START,
    STATE_DIV,
    STATE_ID,
    STATE_QMARK,
    STATE_SPACE,
    STATE_QUOTATION_MARK,
    STATE_NUMBER,
    STATE_EXPR,
    STATE_COMMENT,
    STATE_DOUBLE,
    STATE_EXP,
    STATE_EXP_F,
    STATE_NOTEQ,
    STATE_DOUBLEDOT,
    STATE_EQL,
    STATE_NEQL_1,
    STATE_NEQL_E,
    STATE_EQL_E,
    STATE_SUB,
    STATE_B_COMM_S,
    STATE_B_COMM,
    STATE_B_COMM_TE,
    STATE_NUM,
    STATE_LTE,
    STATE_GTE,
    STATE_SLASH,
    STATE_CHAR,
    STATE_CHAR_1,
    STATE_SCOL,
    STATE_VAR,
    STATE_HEX,
    STATE_HEX_1,
    STATE_NEED_NUM_EXP,
    STATE_NEED_NUM_DBL
} State;

/**
 * @struct Data of the token, like string, integer...
 * 
 */
typedef struct
{
    char *string;    // String or ID
    int integer;     // Int
    float number;    // Double
    Keyword keyword; // Keyword
    bool boolean;
} tokenAttribute;

/**
 * @struct Token representation.
 */
typedef struct
{
    tokenType type;           // Token type
    tokenAttribute attribute; // Token attribute
} Token;

/**
 * @brief initializes scanner
 *
 * @param file file which scanner will read from
 */
void scanner_init(FILE *file);

/**
 * @brief Generate new Token
 *
 * @return Token
 */
Token getToken();

/**
 * @brief checks if token is a keyword
 *
 * @param token token to be evaluated
 * @param name name of keyword
 * @return Token
 */
Token isKeyword(Token token, char *name);

/**
 * @brief converts octal number to decimal number
 *
 * @param n octal number
 * @return int ... decimal number
 */
int OctalToDecimal(int n);

/**
 * @brief calculate the power raised to the base value
 *
 * @param base base
 * @param exp exponent
 * @return int result
 */
int myPow(int base, int exp);

/**
 * @brief allocate memmory for the string
 *
 * @return pointer to the string
 */
char *allocName();

#endif