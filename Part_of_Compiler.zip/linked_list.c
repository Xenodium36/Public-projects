/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Authors:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 2
 #
 ####################################################################################################
*/

#include "linked_list.h"

// this link always point to first Link
struct gen_node *head = NULL;

// this link always point to last Link
struct gen_node *last = NULL;

struct linked_list *initLinkedList()
{
   struct linked_list *tmp = (struct linked_list *)malloc(sizeof(struct linked_list));
   return tmp;
}

// is list empty
bool isEmpty(struct linked_list *linked_list)
{
   return linked_list->head == NULL;
}

int length(struct linked_list *linked_list)
{
   int length = 0;
   struct gen_node *current;

   for (current = linked_list->head; current != NULL; current = current->next)
   {
      length++;
   }

   return length;
}

// insert link at the last location
void insertLast(struct linked_list *linked_list, struct ast_node *data)
{

   // create a link
   struct gen_node *link = (struct gen_node *)malloc(sizeof(struct gen_node));
   link->data = data;

   if (isEmpty(linked_list))
   {
      // make it the last link
      linked_list->head = link;
      linked_list->last = link;
   }
   else
   {
      // make link a new last link
      linked_list->last->next = link;

      // mark old last node as prev of new link
      link->prev = linked_list->last;
   }

   // point last to new last node
   linked_list->last = link;
}

// delete first item
struct ast_node *deleteFirst(struct linked_list *linked_list)
{
   if (linked_list->head)
   {
      // save reference to first link
      struct gen_node *tempLink = linked_list->head;

      // if only one link
      if (linked_list->head->next == NULL)
      {
         linked_list->last = NULL;
      }
      else
      {
         linked_list->head->next->prev = NULL;
      }

      linked_list->head = linked_list->head->next;
      // return the deleted link
      return tempLink->data;
   }
   return NULL;
}

struct ast_node *deleteLast(struct linked_list *linked_list)
{
   // save reference to last link
   if (linked_list->last)
   {
      struct gen_node *tempLink = linked_list->last;

      // if only one link
      if (linked_list->head->next == NULL)
      {
         linked_list->head = NULL;
      }
      else
      {
         linked_list->last->prev->next = NULL;
      }

      linked_list->last = linked_list->last->prev;

      // return the deleted link
      return tempLink->data;
   }
   return NULL;
}