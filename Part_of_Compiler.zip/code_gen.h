/*
 ####################################################################################################
 # Title: Implementation of the imperative language compiler IFJ22
 #
 # Authors:
 # - xharsa01 - Dominik Harsanik
 #
 # Version: 3
 #
 ####################################################################################################
*/

#ifndef IFJ_PROJ_2022_CODEGEN_H
#define IFJ_PROJ_2022_CODEGEN_H

#pragma once
#include <stdlib.h>
#include <stdio.h>
#include "ast.h"
#include "buffer.h"
#include "generator.h"
#include "linked_list.h"
/**
 * @brief Main function of code generation
 * Fuction is called after AST is created
 * 
 * @param ast_node 
 */
void gen_assembly(struct ast_node *ast_node);

/**
 * @brief Generation of code depends on the node type in AST
 * 
 */
void crossroad();

/**
 * @brief AST is converted into stack using preorder traversal algorithm
 * @param ast_node Parent node of AST
 * 
 */
void fill_Stack(struct ast_node *);

/**
 * @brief Function call needs to be inserted with postorder traversal algorithm into Expression stack
 * @param ast_node Parent node of function call in AST
 * 
 */
void insertFncCall(struct ast_node *);

/**
 * @brief Fill Expression stack with expression
 * Automatically clear expression from main Stack
 * @param ast_node Parent node of expression in AST
 * 
 */
void fill_ExprStack(struct ast_node *);

/**
 * @brief Clear expression stack, shouldnt be needed
 * 
 */
void clearExprStack();

/**
 * @brief If function call is found, it is needed to push function parameters to the stack in the assembly code
 * 
 */
void fnc_call();

/**
 * @brief If expression is found on stack in function crossroad, 
 * then generate assembly code using this function
 * 
 */
void expr();

/**
 * @brief 
 * 
 * @param tmp1 
 * @param exp 
 */
void assign_expr_stack(struct ast_node *tmp1, struct node_data_as_expression *exp);

/**
 * @brief 
 * 
 * @param tmp1 
 * @param tmp2 
 * @param exp 
 */
void assign_expr(struct ast_node *tmp1, struct ast_node *tmp2, struct node_data_as_expression *exp);

/**
 * @brief 
 * 
 * @param tmp1 
 * @param tmp2 
 * @param exp 
 */
void math_expr(struct ast_node *tmp1, struct ast_node *tmp2, struct node_data_as_expression *exp);

/**
 * @brief 
 * 
 * @param tmp1 
 */
void expr_value(struct ast_node *tmp1);

/**
 * @brief 
 * 
 * @param fnc_call 
 */
void fnc_call_exp(struct ast_node *fnc_call);

#endif